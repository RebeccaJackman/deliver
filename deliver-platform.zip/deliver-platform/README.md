# Deliver — Portfolio Intelligence Platform

An AI-powered platform that transforms fragmented programme documents into evidence-based Portfolio Intelligence Records.

## What it does

Upload your programme documents — narrative reports, budget spreadsheets, indicator trackers, risk registers — and Deliver reads across all of them, extracts structured information, reconciles inconsistencies, and generates a Portfolio Intelligence Record with RAG health assessments, financial commentary, and management recommendations.

## How to deploy (Streamlit Cloud — free)

1. Create account at streamlit.io
2. Create a GitHub repository
3. Upload these files: app.py, deliver_system_prompt.py, requirements.txt
4. In Streamlit Cloud click New app, connect your repository
5. Add your Anthropic API key in Settings → Secrets:
   ```
   ANTHROPIC_API_KEY = "your-key-here"
   ```
6. Deploy

## How to use

1. Add programme context in the sidebar (optional but helpful)
2. Select document category and upload your documents
3. Click Generate Portfolio Intelligence
4. Review the Portfolio Intelligence Record
5. Ask follow-up questions in the Ask tab
6. Export as text

## Documents supported

- Word (.docx) — narrative reports, donor reports
- Excel (.xlsx, .xls) — budgets, indicator trackers, risk registers, workplans
- PDF (.pdf) — any programme document
- CSV (.csv) — data exports
- Text (.txt) — any text-based document

## The two engines

Document Intelligence Engine — reads across uploaded documents, extracts structured information, reconciles inconsistencies, flags confidence levels

Portfolio Intelligence Engine — applies programme management reasoning to generate evidence-backed RAG health assessments, executive narratives, and management recommendations
